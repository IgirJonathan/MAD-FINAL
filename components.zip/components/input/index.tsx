import {
  StyleSheet,
  View,
  Text,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import React from 'react';

const Input = ({label, placeholder, onChangeText, ...rest}) => {
  return (
    <View>
      <Text style={Styles.label}>{label}</Text>
      <TextInput
        placeholder={placeholder}
        style={Styles.input}
        onChangeText={onChangeText}></TextInput>
    </View>
  );
};

export default Input;

const Styles = StyleSheet.create({
  label: {
    fontSize: 18,
    fontWeight: 'bold',
    color: 'black',
    marginLeft: 10,
  },
  input: {
    width: '95%',
    borderWidth: 1,
    borderColor: 'black',
    borderRadius: 10,
    padding: 10,
    fontSize: 16,
    marginBottom: 20,
    marginTop: 20,
    marginLeft: 10,
  },
});
