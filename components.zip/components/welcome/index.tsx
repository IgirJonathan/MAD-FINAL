import React from 'react';
import {Text, StyleSheet, View} from 'react-native';

type WelcomeProps = {
  title?: string;
};

const welcome = ({title = 'Welcome'}: WelcomeProps) => {
  return (
    <View>
      <Text style={styles.title}>{title}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'black',
    textAlign: 'center',
    marginTop: 30,
    marginBottom: 30,
    marginLeft: 10,
  },
});

export default welcome;
